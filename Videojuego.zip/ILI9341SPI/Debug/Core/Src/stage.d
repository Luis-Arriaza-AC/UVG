Core/Src/stage.o: ../Core/Src/stage.c ../Core/Inc/stage.h \
 ../Core/Inc/graphics.h
../Core/Inc/stage.h:
../Core/Inc/graphics.h:
